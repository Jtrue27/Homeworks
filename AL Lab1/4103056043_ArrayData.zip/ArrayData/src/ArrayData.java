import java.util.*;//import package

public class ArrayData {
	/*data*/
	public double[] C;
	/*method*/
	public ArrayData(double[] A){ //AR
	  C=new double[A.length];      //double[] C=new double[A.length]; ���ƫŧi�|�y��Error
	  for(int i=0;i<A.length;i++){
		  C[i]=A[i];   
	  }	
	}
	public double max(){
		double maxn=C[0];
		for(int i=1;i<C.length;i++){
			if(C[i]>maxn) maxn=C[i];
		}
		return maxn;
	}	
	public double avg(){
		double sum=0;
		double averge;
		for (int i=0;i<C.length;i++){
			sum+=C[i];
		}
		averge=sum/C.length;
			return averge;
	}
	public void reverse(){
		double[]D= new double[C.length];
		int j=0;
		for (int i=C.length-1;i>=0;i--){
			D[j++]=C[i];	
		}
		for(int i=0;i<C.length;i++){
			System.out.print(D[i]+" ");
			
		}
		System.out.println();
	}
	public void suffle(){
		Random rnd = new Random();
		for(int i=C.length-1;i>0;i--){
			int index=rnd.nextInt(i+1);
			double tmp=C[index];
			C[index]=C[i];
			C[i]=tmp;
			
		}
		for(int i=0;i<C.length;i++){
			System.out.print(C[i]+" ");
			
		}
		System.out.println();
	}
	public String toString(){		
		return Arrays.toString(C);
	}
	public  double inner_product(double[]B){
		double ip=0;
		for(int i=0;i<C.length;i++){
			ip+=C[i]*B[i];
		}
		return ip;
	}
		
	public static void main(String[] arg) {
		double[] a={1,2,3};
		double[] b={4,5,6};
	    ArrayData AA=new ArrayData(a);//��l��
	    ArrayData BB=new ArrayData(b);//��l��
        System.out.printf("�}�C������:%7.2f\n",AA.avg()); //����
	    System.out.printf("�}�C�̤j��:%7.2f\n",AA.max()); //�̤j��
	    System.out.printf("��}�C���n��:%6.2f\n",AA.inner_product(b));//�p�⤺�n    
	    System.out.println("�}�C�ഫ�r��:"+AA.toString()); //�ഫ��r��
	    System.out.print("½���}�C:  ");    AA.reverse();//½��}�C
	    System.out.print("�H���}�C:    ");      AA.suffle(); //�H���}�C
	  
	    
	}
	
		
}


