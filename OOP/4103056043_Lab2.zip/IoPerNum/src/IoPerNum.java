import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
//import �Ҧ���package
public class IoPerNum {
	/*data*/
	public int perfectsum=0;
	public int number;
	/*method*/
	public IoPerNum(int num){    //constructor
		number=num;
	}
	public boolean IsPerfect(int number){  //�P�_�O�_��Perfect Number
		for(int i=1;i<number;i++){
			if(number%i==0){
				perfectsum+=i;
			}
		}
		if(perfectsum==number) return true;
		else                   return false;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner inputStream=null;        //Ū�ɮ׳]��null��l��
		PrintWriter outputStream=null;   //�g�ɮ׳]��null��l��
		try //�}��
	    {
	       inputStream=new Scanner(new FileInputStream("inFile.txt"));
	       outputStream=new PrintWriter(new FileOutputStream("outFile.txt"));
	    }
	    catch(FileNotFoundException ex)//�Y�}�ɥ���
	    {
	       System.out.println("File can not find or open");
	       System.exit(0); //�������}
	    }
		
		while(inputStream.hasNextInt()){    //��input�@��Ū����
			int x=inputStream.nextInt();
			IoPerNum integer=new IoPerNum(x);  //��l�ƪ���
		    if(integer.IsPerfect(x)){
			outputStream.printf("%d is a perfect number.\r\n",x);   //�g�J�ɮ�
		    }
		    else {
		    outputStream.printf("%d is not a perfect number.\r\n",x);//�g�J�ɮ�
		    }
		}
	    inputStream.close();//����
	    outputStream.close();//����
	}

}
