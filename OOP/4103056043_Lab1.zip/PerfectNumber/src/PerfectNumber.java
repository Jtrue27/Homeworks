import java.util.*;                        //import package
public class PerfectNumber {               //class���W�٭n�M�{���W�٤@��
	/*data*/
	public int number;    
	public int perfectsum;    
	/*method*/
	public PerfectNumber(int num){         //constructor   
		number=num;
	}
	public boolean IsPerfect(int number){  //�P�_�O�_�Operfect number 
		for(int i=1;i<number;i++){
			if(number%i==0){
				perfectsum+=i;
			}
		}
		if(perfectsum==number) return true;
		else                   return false;
	}

	public static void main(String[] args) {
        System.out.print("Enter a integer:");
        Scanner  input=new Scanner(System.in);  
        int num=input.nextInt();                //����input�q��LŪ�J�Ʀr
        PerfectNumber x=new PerfectNumber(num); //�����l�� 
        if(x.IsPerfect(num)==true) System.out.println("The number is perfect.");//��X�P�_
        else   System.out.println("The number is nonperfect.");
	}

}
