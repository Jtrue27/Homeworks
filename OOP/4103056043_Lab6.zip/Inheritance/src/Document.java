
public class Document {//�����O
		private String text;
		public String toString(){
			return text;
		}
	   public Document(){
		   text=null;
	   }
	   public void setText(String input){
		   text=input;
	   }
	   public String getText(){
		   return text;
	   }
	   public static Boolean ContainsKeyword(Document docObject,String keyword){//�P�_���S���]�tkeyword
		   if(docObject.toString().indexOf(keyword,0)>=0) return true;
		   return false;
	   }
	   public static void main(String[] args) {
			// TODO Auto-generated method stub
	      Email sampleObject1=new Email();
	      File sampleObject2=new File();
	      sampleObject1.setSender("Eason");
	      sampleObject1.setRecipient("Dr.Liou");
	      sampleObject1.setTitle("Hello Teacher");
	      sampleObject1.setText("Java course is great,I love it");
	      
	      sampleObject2.setPathname("D:/datafile.txt");
	      sampleObject2.setText("Lab6 is about the use of inheritance.");
	      if(ContainsKeyword(sampleObject1,"Java"))
	    	  System.out.println(sampleObject1);
	      if(ContainsKeyword(sampleObject2,"Java"))
	    	  System.out.println(sampleObject2); 
		}
	      
}
	    
	   


