import java.io.*;
import java.util.*;
public class ProductRating {
	/*data encapsulation*/
	private int rateA;
	private int rateB;
	private int rateC;
	private int rateD;
	private int rateE;
	private double sumA=0;
	private double sumB=0;
	private double sumC=0;
	private double sumD=0;
	private double sumE=0;
	private int sizeA=0;
	private int sizeB=0;
	private int sizeC=0;
	private int sizeD=0;
	private int sizeE=0;
	private double AvgA=0;
	private double AvgB=0;
	private double AvgC=0;
	private double AvgD=0;
	private double AvgE=0;
   /*method*/

	public  void computeAvgA(){
		AvgA=sumA/sizeA;
	}
	public  void computeAvgB(){
		AvgB=sumB/sizeB;
	}
	public  void computeAvgC(){
		AvgC=sumC/sizeC;
	}
	public  void computeAvgD(){
		AvgD=sumD/sizeD;
	}
	public  void computeAvgE(){
		AvgE=sumE/sizeE;
	}
			
    public void updateRateA(int rateA){
    	this.rateA=rateA;
    	
    }
    public void updateRateB(int rateB){
    	this.rateB=rateB;
    
    }
    public void updateRateC(int rateC){
    	this.rateC=rateC;
    	
    }
    public void updateRateD(int rateD){
    	this.rateD=rateD;
    	
    }
    public void updateRateE(int rateE){
    	this.rateE=rateE;
    	
    }
    public int getRateA(){
    	return rateA;
    }
    public int getRateB(){
    	return rateB;
    }
    public int getRateC(){
    	return rateC;
    }
    public int getRateD(){
    	return rateD;
    }
    public int getRateE(){
    	return rateE;
    }

    public void computeSumAsizeA(int add){
    	if(add!=0){ 
    		sumA+=add;
    	    sizeA++;	
    	}
    	
   }
    public void computeSumBsizeB(int add){
    	if(add!=0){ 
    		sumB+=add;
    	    sizeB++;	
    	}
    	
   }
    public void computeSumCsizeC(int add){
    	if(add!=0){ 
    		sumC+=add;
    	    sizeC++;	
    	}
    	
   }
    public void computeSumDsizeD(int add){
    	if(add!=0){ 
    		sumD+=add;
    	    sizeD++;	
    	}
    
   }
    public void computeSumEsizeE(int add){
    	if(add!=0){ 
    		sumE+=add;
    	    sizeE++;	
    	}
    
   }

    public double getAvgA(){
    	return AvgA;
    }
    public double getAvgB(){
    	return AvgB;
    } 
    public double getAvgC(){
    	return AvgC;
    } 
    public double getAvgD(){
    	return AvgD;
    } 
    public double getAvgE(){
    	return AvgE;
    }
    
    
    public double getSumA(){
    	return sumA;
    }
    public double getSumB(){
    	return sumB;
    }
    public double getSumC(){
    	return sumC;
    }
    public double getSumD(){
    	return sumD;
    }
    public double getSumE(){
    	return sumE;
    }

 
	public static void main(String[] args) {
		/*Part1*/
		ProductRating object=new ProductRating();

		Scanner inputStream=null;   
		try
		{
			inputStream=new Scanner(new FileInputStream("inFile4.txt")); //�}��
		
		}
		catch(FileNotFoundException ex)
		{   
			System.out.println("File can not open!");
			System.exit(0);
		}
		String dontwant1=inputStream.nextLine();//���⤣�n���r��ᱼ
		dontwant1=null;
		while(inputStream.hasNextLine()){	//Ū��
			String line=inputStream.nextLine();
			StringTokenizer factory=new StringTokenizer(line,",");
			object.updateRateA(Integer.parseInt(factory.nextToken()));
			object.updateRateB(Integer.parseInt(factory.nextToken()));
			object.updateRateC(Integer.parseInt(factory.nextToken()));
			object.updateRateD(Integer.parseInt(factory.nextToken()));
			object.updateRateE(Integer.parseInt(factory.nextToken()));
			object.computeSumAsizeA(object.getRateA());
			object.computeSumBsizeB(object.getRateB());
			object.computeSumCsizeC(object.getRateC());
			object.computeSumDsizeD(object.getRateD());
			object.computeSumEsizeE(object.getRateE());
			}
			object.computeAvgA();
			object.computeAvgB();
			object.computeAvgC();
			object.computeAvgD();
			object.computeAvgE();
		System.out.printf("%2s%7s\r\n","���~","�U�ȥ�������");
		System.out.printf("%2s%7.1f\r\n","A",object.getAvgA());
		System.out.printf("%2s%7.1f\r\n","B",object.getAvgB());
		System.out.printf("%2s%7.1f\r\n","C",object.getAvgC());
		System.out.printf("%2s%7.1f\r\n","D",object.getAvgD());
		System.out.printf("%2s%7.1f\r\n","E",object.getAvgE());

		inputStream.close();

		/*Part 2*/
		try
		{
			inputStream=new Scanner(new FileInputStream("inFile4.txt"));
		}
		catch(FileNotFoundException ex)
		{   
			System.out.println("File can not open!");
			System.exit(0);
		}
		System.out.println("�п�J�A�ﲣ�~A, B, C, D�������G");
		Scanner keyboard=new Scanner(System.in);
		String inputline=keyboard.nextLine();
		StringTokenizer factory1=new StringTokenizer(inputline,",");
		int Au=Integer.parseInt(factory1.nextToken());
		int Bu=Integer.parseInt(factory1.nextToken());
		int Cu=Integer.parseInt(factory1.nextToken());
		int Du=Integer.parseInt(factory1.nextToken());
		int min=1000;
		int IrespectE=0;
		double DrespectE=0; 
		int simarity2up=0;
		int Ac;
		int Bc;
		int Cc;
		int Dc;
		int Ec;
		String dontwant2=inputStream.nextLine();//���n���r��
		dontwant2=null;
		while(inputStream.hasNextLine()){	
			String line=inputStream.nextLine();
			StringTokenizer factory=new StringTokenizer(line,",");
			object.updateRateA(Integer.parseInt(factory.nextToken()));
			object.updateRateB(Integer.parseInt(factory.nextToken()));
			object.updateRateC(Integer.parseInt(factory.nextToken()));
			object.updateRateD(Integer.parseInt(factory.nextToken()));
			object.updateRateE(Integer.parseInt(factory.nextToken()));
			Ac=object.getRateA();
			Bc=object.getRateB();
			Cc=object.getRateC();
			Dc=object.getRateD();
			Ec=object.getRateE();		
			
			int simarity=Math.abs(Au-Ac)+Math.abs(Bu-Bc)+Math.abs(Cu-Cc)+Math.abs(Dc-Dc);
			if(simarity<min) {  //�p�G�ۦ��׶V�p�N�]�w���L
				min=simarity;
				IrespectE=object.getRateE();
				simarity2up=0;
			}
			else if(simarity==min){
				DrespectE=object.getAvgE();  //�p�G����ӥH�W�ۦP ������
				simarity2up=1;
			}
			
		}
		if(simarity2up==1)
		System.out.println("���{���w���A�ﲣ�~E�������O"+DrespectE);
		
		else 
			System.out.println("���{���w���A�ﲣ�~E�������O"+IrespectE);
		inputStream.close();
			
	}
	

}
