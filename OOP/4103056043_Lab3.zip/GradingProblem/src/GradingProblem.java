import java.io.*;
import java.util.*;
public class GradingProblem {
	/*Data*/
	private String id=null;
	private int quiz1=0;
	private int quiz2=0;
	private int quiz3=0;
	private int midterm=0;
	private int finaltest=0;
	private double grade=0;
	private  String letter=null;
	/*Mutator*/
	public void updateID(String id){
		this.id=id;
	}
 	public void updateQuiz1(int quiz1){
		this.quiz1=quiz1;
	}
	public void updateQuiz2(int quiz2){
		this.quiz2=quiz2;
	}
    public void updateQuiz3(int quiz3){
		this.quiz3=quiz3;
	}
	public void updateMidterm(int midterm){
		this.midterm=midterm;
	}
    public void updateFinaltest(int finaltest){
		this.finaltest=finaltest;
	}
	public void updateNumericGrade(double grade){
		this.grade=grade;
	}
    public void updateLetterGrade(String letter){
    	this.letter=letter;
    }
    /*Accessor*/
	public String getID(){
		return id;
	}
	public int getQuiz1(){
		return quiz1;
	}
	public int getQuiz2(){
		return quiz2;
	}
	public int getQuiz3(){
		return quiz3;
	}
	public int getMidterm(){
		return midterm;
	}
	public int getFinaltest(){
		return finaltest;
	}
	public double  getNumericGrade(){
		 return grade;
	}
    public String getLetterGrade(){
    	return letter;
    }
   /*Other Methods*/
    public String toString(){
    	return id+quiz1+quiz2+quiz3+midterm+finaltest+grade+letter+"\r\n";
    }
    public double computeNumericGrade(){
      return 	((quiz1+quiz2+quiz3)*10*0.4)/3+(midterm*0.35)+(finaltest*0.25);
    }
    public String computeLetterGrade(){
    	if(grade>=90) return "A";
    	else if(grade<90&&grade>=80) return "B";
    	else if(grade<80&&grade>=70) return "C";
    	else if(grade<70&&grade>=60) return "D";
    	else return "F";
    }
    public boolean equals(GradingProblem obj){
    	return ((this.id).equals(obj.id)&&(this.quiz1==obj.quiz1)&&(this.quiz3==obj.quiz3)&&(this.midterm==obj.midterm)
    			&&(this.finaltest==obj.finaltest)&&(this.grade==obj.grade)&&(this.letter).equals(obj.letter));
    
    }

 	
}



