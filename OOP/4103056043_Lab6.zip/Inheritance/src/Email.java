
public class Email extends Document{//�l���O
	private String sender;
	private String recipient;
	private String title;
	public void setSender(String input){
		   sender=input;
	   }
    public String getSender(){
		   return sender;
	   }
    public void setRecipient(String input){
		   recipient=input;
	   }
    public String getRecipient(){
		   return recipient;
	   }
    public void setTitle(String input){
		   title=input;
	   }
    public String getTitle(){
		   return title;
	   }
	public String toString(){
		return "Sender:"+sender+"\r\n"+"Recipient:"+recipient+"\r\n"+"Title:"+title+"\r\n"+"Text:"+getText();
	}
}
