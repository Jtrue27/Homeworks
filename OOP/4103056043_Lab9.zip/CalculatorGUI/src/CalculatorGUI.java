import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CalculatorGUI extends JFrame  {//�~�Ӧ�JFrame
	/*GUI�ɭ��ܼ�*/
	public static final int Width = 400;
	public static final int Height = 736;
	public static final int numberOfChar = 25;
	public JTextField resultField = new JTextField(25);
	public JTextField operandField = new JTextField(25);
	public String resultString = "0.0";
	public String operandString = "";
	public String Operator;
	/*�U�ت��A��Flag*/
	public boolean hasOperandFlag;
	public boolean hasOperatorFlag;
	public boolean hasPointFlag; 
	public boolean errorFlag;
	public  boolean firstInput=true;
	public  boolean firstOperatorClick=true;
	public double answer = 0.0;//�B�⪺�Ʀr
	/*Button*/
	public JButton addButton;
	public JButton subButton;
	public JButton mulButton;
	public JButton divButton;
	public JButton sqrtButton;
	public JButton equalButton;
	public JButton clrButton;
	public JButton resetButton;
	public JButton dotButton;
	public JButton Button0;
	public JButton Button1;
	public JButton Button2;
	public JButton Button3;
	public JButton Button4;
	public JButton Button5;
	public JButton Button6;
	public JButton Button7;
	public JButton Button8;
	public JButton Button9;
	
	
	
	public class Number_Of_Listener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			//�M�����~�T��
			if(errorFlag==true){
				operandString="";
				resultString=""+answer;
				errorFlag=false;
			}
			String buttonNumber=e.getActionCommand();
			if(buttonNumber.equals(".")){//�p�G��J�p���I
				if(hasPointFlag==false){
					operandString+=buttonNumber;//0.1...
					hasPointFlag=true;//�N�����p���I�F
				}
			}
			else{//�Y�O���`�Ʀr
		    operandString += buttonNumber;
			}
		
           hasOperandFlag=true;//�N�����B��l
		   resultField.setText(resultString);
           operandField.setText(operandString);
           
            
         
		}
	}
	
	public class Operator_Of_Listener implements ActionListener{
		public void actionPerformed(ActionEvent e){
		
		if(firstOperatorClick==true){
				resultField.setText(operandString);
				answer=Double.parseDouble(operandString);
				if(firstOperatorClick==true)
				resultString=""+answer;
				resultField.setText(resultString);
				operandString="";
				operandField.setText(operandString);
				firstOperatorClick=false;
				hasOperatorFlag=true;
				hasOperandFlag=true;
				hasPointFlag=false;
				
			}
			
			
		if(firstOperatorClick==false){	
		 if(true){	
			if(errorFlag==true){//��J���~�B��l
				operandString="";//�B�⤸�M��
				resultString=""+answer;//�����쵪��
				errorFlag=false;//��_�S��
			}
			String command=e.getActionCommand();
			if(command.equals("=")){                  
				if(hasOperandFlag==true){
					resultString+=operandString;
					resultField.setText(resultString);
				}
			
			try{
				
				
				
				double tmp=Double.parseDouble(operandString);
				operandField.setText("");
				if(Operator==null){
					
				}
				else if(Operator.equals("sqrt")){
					hasOperandFlag=true;
					if(answer<0){
						throw new NotANumberException();
					}
					
					answer=Math.sqrt(answer);
					firstOperatorClick=false;
				}
				else if(Operator.equals("+")){
					
					answer+=tmp;
					resultField.setText(String.valueOf(answer));
					operandField.setText("");
					firstOperatorClick=false;
					
				}
				else if(Operator.equals("-")){
					answer-=tmp;
					resultField.setText(String.valueOf(answer));
					operandField.setText("");
					firstOperatorClick=false;
				}
				else if(Operator.equals("*")){
					answer*=tmp;
					resultField.setText(String.valueOf(answer));
					operandField.setText("");
					firstOperatorClick=false;
				}
             
				
               
				else {
                     if (tmp==0) {
                         throw new DivisonByZeroException();

                     }
                     answer/=tmp;
                     resultField.setText(String.valueOf(answer));//result setText
                     operandField.setText("");
                     firstOperatorClick=false;
                    
				}
				resultString=""+answer;
				operandString="";
			}
				catch(DivisonByZeroException ee){
					 operandString = "Can not divided by 0";
					 answer = 0.0;
	                    errorFlag = true;
	                    resultString=""+answer;
	                    resultField.setText(resultString);
	                    firstOperatorClick=true;
				}
			catch(NotANumberException eee){
				operandString="���O�@�Ӽƭ�";
				answer=0;
				resultString=""+answer;
                resultField.setText(resultString);
				errorFlag=true;
				firstOperatorClick=true;
			}
				Operator = null;
                hasPointFlag = false;
                hasOperandFlag = false;
                hasOperatorFlag = false;
			}
			else if (hasOperatorFlag == true) //�Y�@����J�B�⤸�h���ܤ����
			{
                //�ק�B��l 
                Operator = command;
            } 
			else {
               
                Operator = command;
                hasOperatorFlag = true;
            }
            resultField.setText(resultString);
            operandField.setText(operandString);
        
		}
		}
		}
	}
	public class OtherButton_Of_Listener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			String OtherButtoncommand=e.getActionCommand();
			switch(OtherButtoncommand){
			case "Clear":
				operandString="";
				hasOperandFlag=false;
				hasPointFlag=false;
				break;
			case "Reset":
				resultString="0.0";	
				answer=0.0;
				hasOperatorFlag=false;
				Operator=null;
				firstOperatorClick=true;
				firstOperatorClick=true;
				break;
			case "sqrt":
				if(firstOperatorClick==true){
	                //resultAns=Double.parseDouble(operandText);
					resultField.setText(operandString);
					answer=Double.parseDouble(operandString);
					if(firstOperatorClick==true)
					resultString=""+answer;
					resultField.setText(resultString);
					operandString="";
					operandField.setText(operandString);
					firstOperatorClick=false;
					hasOperatorFlag=true;
					hasOperandFlag=true;
					hasPointFlag=false;
					
				}
				answer=Math.sqrt(answer);
				resultString=""+answer;
				resultField.setText(resultString);
				operandString="";
				operandField.setText(operandString);
			}
			
			operandField.setText(operandString);
			resultField.setText(resultString);
		
		}
	}
		
	public CalculatorGUI()
	{
		super("Calculator");
		setSize(Width,Height);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);	
		setResizable(false);
		
		resultField.setText(resultString);
		resultField.setEditable(false);
		resultField.setBounds(60, 0, Width, 50);//�]�w��m
        add(resultField);
        
        operandField.setText(operandString);
        operandField.setEditable(false);
        operandField.setBounds(60, 50, Width, 50);//�]�w��m
        add(operandField);
        //�[label
        JLabel lab = new JLabel("Result", JLabel.RIGHT);
        lab.setLabelFor(resultField);
        lab.setBounds(0, 10, 60, 30);//�]�w��m
        add(lab);

        lab = new JLabel("Operand", JLabel.RIGHT);
        lab.setLabelFor(operandField);
        lab.setBounds(0,60 , 60, 30);//�]�w��m
        add(lab);
        
        JPanel numberPanel = new JPanel();
        JButton button;
        numberPanel.setLayout(new GridLayout(4, 3));
        JButton Button7 =new JButton("7");
		Button7.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button7);
		Button8 =new JButton("8");
		Button8.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button8);
		Button9 =new JButton("9");
		Button9.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button9);
		Button4=new JButton("4");
		Button4.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button4);
		Button5 =new JButton("5");
		Button5.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button5);
		Button6 =new JButton("6");
		Button6.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button6);
		Button1 =new JButton("1");
		Button1.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button1);
		Button2 =new JButton("2");
		Button2.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button2);
		Button3 =new JButton("3");
		Button3.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button3);
		Button0 =new JButton("0");
		Button0.addActionListener(new Number_Of_Listener());
		numberPanel.add(Button0);
        button = new JButton(".");
        button.setSize(50, 50);
        button.addActionListener(new Number_Of_Listener());
        numberPanel.add(button);
        numberPanel.setBounds(0, 200,300 , 500);//�]�w��m
        numberPanel.setBackground(Color.LIGHT_GRAY);
        add(numberPanel);
       
        
        
        JPanel operatorPanel = new JPanel();
        operatorPanel.setLayout(new GridLayout(6, 1));
        addButton =new JButton("+");
		addButton.addActionListener(new Operator_Of_Listener());
		operatorPanel.add(addButton);
		subButton =new JButton("-");
		subButton.addActionListener(new Operator_Of_Listener());
		operatorPanel.add(subButton);
		mulButton =new JButton("*");
		mulButton.addActionListener(new Operator_Of_Listener());
		operatorPanel.add(mulButton);
		divButton =new JButton("/");
		divButton.addActionListener(new Operator_Of_Listener());
		operatorPanel.add(divButton);
        
        sqrtButton =new JButton("sqrt");
        sqrtButton.setSize(70, 70);
        sqrtButton.addActionListener(new OtherButton_Of_Listener());
        operatorPanel.add(sqrtButton);
        equalButton=new JButton("=");
        equalButton.setSize(70, 70);
        equalButton.addActionListener(new Operator_Of_Listener());
        operatorPanel.add(equalButton);
        
        operatorPanel.setBounds(300, 100, 100, 600);//x,y,width,hight//�]�w��m
        add(operatorPanel);

        resetButton = new JButton("Reset");
        resetButton.addActionListener(new OtherButton_Of_Listener());
        resetButton.setBounds(0, 100, 150, 100);//�]�w��m
        add(resetButton);

        clrButton = new JButton("Clear");
        clrButton.addActionListener(new OtherButton_Of_Listener());
        clrButton.setBounds(150, 100, 150, 100);//�]�w��m
        add(clrButton);

        hasOperandFlag = false;
        hasOperatorFlag = false;
        hasPointFlag = false;
        errorFlag = false;
        answer = 0.0;
        Operator = null;
        
        
    }
	
	public static void main(String[] args) {
		CalculatorGUI Ca2 = new CalculatorGUI();
		Ca2.setVisible(true);//�]�w�i��
	}



	

}
