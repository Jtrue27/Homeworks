
public class NotANumberException extends Exception {
	public NotANumberException(){
		super("Not a Number");
	
	}
}
