
public class Rectangle extends Point {
	private int width;
	private int height;
	public Rectangle(String name,int x,int y,int width,int height){//�غc�l
		super(name,x,y);
		this.height=height;
		this.width=width;
	}
	public double getArea(){//overriding
		return width*height;
	}
	public String toString(){//overriding
		return super.toString()+" is the upper left corner. The width is "+width+" and the height is "+height;
	}
}
