
public class Point extends Shape { //�~��Shape
    protected int x;  //protected�i���~�Ӫ����O�ϥ�
    protected int y;  //�P�W
    
    public Point(String name,int x,int y){//�غc�l
    	this.name=name;
    	this.x=x;
    	this.y=y;
    }
	
	public double getArea() {//overriding
		return 0;
	}
	public String toString(){//overriding
		return super.toString()+"Point="+"("+x+","+y+")";
	}

}
