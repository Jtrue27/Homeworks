public class UnknownOperatorException extends Exception{
    public UnknownOperatorException(){
    super("It is an unknown operator.");
    }
    public UnknownOperatorException(String message){
        super(message+" is an unknown operator.");
    }

}