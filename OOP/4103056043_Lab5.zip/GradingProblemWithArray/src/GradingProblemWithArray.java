import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;
public class GradingProblemWithArray {
	 public static String id[]=null;
	 public static int []quiz1={0};
	 public static int []quiz2={0};
	 public static int []quiz3={0};
	 public static int []midterm={0};
	 public static int []finaltest={0};
	 public static double []grade={0};
	 public static String []letter=null;
	 public int length=0;
	 //Constructor
	 public GradingProblemWithArray(){
		 id=new String[50];
			quiz1=new int[50];
			quiz2=new int[50];
			quiz3=new int[50];
		    midterm=new int[50];
		    finaltest=new int[50];
		    grade=new double[50];
		    letter=new String[50];

	 }
	 
	 //insertion sort
	 public static void sort(double[]grade,String[]id,int[]quiz1,int[]quiz2,int []quiz3,int []midterm,int []finaltest,String []letter,int numberUsed){
	    	int index,indexOfNextMax;
	    	for(index=0;index<numberUsed;index++){
	    		indexOfNextMax=indexOfMax(index,grade,numberUsed);
	    		interchange(index,indexOfNextMax,grade);
	    		interchange(index,indexOfNextMax,id);
	    		interchange(index,indexOfNextMax,quiz1);
	    		interchange(index,indexOfNextMax,quiz2);
	    		interchange(index,indexOfNextMax,quiz3);
	    		interchange(index,indexOfNextMax,midterm);
	    		interchange(index,indexOfNextMax,finaltest);
	    		interchange(index,indexOfNextMax,letter);
	    	}
	    }
	 //find maxofindex
	 public static int indexOfMax(int startIndex,double []a,int numberUsed){
	    	double max=a[startIndex];
	    	int indexOfMax=startIndex;
	    	int index;
	    	for(index=startIndex+1;index<numberUsed;index++){
	    		if(a[index]>max){
	    			max=a[index];
	    			indexOfMax=index;
	    		}
	    	}
	    	return indexOfMax;
	    }
	    private static void interchange(int i,int j,double[]a){//interchange overloading
	    	double tmp;
	    	tmp=a[i];
	    	a[i]=a[j];
	    	a[j]=tmp;
	    } 
	    private static void interchange(int i,int j,int[]a){//interchange overloading
	    	int tmp;
	    	tmp=a[i];
	    	a[i]=a[j];
	    	a[j]=tmp;
	    }
	    private static void interchange(int i,int j,String[]a){//interchange overloading
	    	String tmp;
	    	tmp=a[i];
	    	a[i]=a[j];
	    	a[j]=tmp;
	    }
	    //�p�⦨�Z
	    public static double computeNumericGrade(int line){
	        return 	((quiz1[line]+quiz2[line]+quiz3[line])*10*0.4)/3+(midterm[line]*0.35)+(finaltest[line]*0.25);
	      }
	    //�p��r�����Z
	    public static String computeLetter(int line){
	    	if(grade[line]>=90) return "A";
	    	else if(grade[line]<90&&grade[line]>=80) return "B";
	    	else if(grade[line]<80&&grade[line]>=70) return "C";
	    	else if(grade[line]<70&&grade[line]>=60) return "D";
	    	else return "F";
	    }
        //�⦨�Z�ন�r��
        public String toString(int line){
	    	
	    	return id[line]+quiz1[line]+quiz2[line]+quiz3[line]+midterm[line]+finaltest[line]+grade[line]+letter[line]+"\r\n";
	    }

        public boolean equals(GradingProblemWithArray obj,int line){
        	return (id[line].equals(obj.id[line])&&(quiz1[line]==obj.quiz1[line])&&(quiz3[line]==obj.quiz3[line])&&(midterm[line]==obj.midterm[line])
        			&&(finaltest[line]==obj.finaltest[line])&&(grade[line]==obj.grade[line])&&(letter[line]).equals(obj.letter[line]));
        
        }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 GradingProblemWithArray object=new GradingProblemWithArray();
		   
			Scanner inputStream=null;        //Ū�ɮ׳]��null��l��
			PrintWriter outputStream=null;
			try //�}��
		    {
		       inputStream=new Scanner(new FileInputStream("inFile5.txt"));  
		       outputStream=new PrintWriter(new FileOutputStream("outFile5.txt"));	
		    }
		    catch(FileNotFoundException ex)//�Y�}�ɥ���
		    {
		       System.out.println("File can not find or open");
		       System.exit(0); //�������}
		    }  
			outputStream.printf("%-5s%6s%6s%7s%8s%6s%13s%12s\r\n","ID","Quiz1" ,"Quiz2" ,"Quiz3", "Midterm" ,"Final","NumericGrade" ,"LetterGrade");
			while(inputStream.hasNextLine()){    
				String inputline=inputStream.nextLine();
				StringTokenizer factory =new StringTokenizer(inputline,"  ");
				id[object.length]=factory.nextToken();
			    quiz1[object.length]=Integer.parseInt(factory.nextToken());
				quiz2[object.length]=Integer.parseInt(factory.nextToken());
				quiz3[object.length]=Integer.parseInt(factory.nextToken());
				midterm[object.length]=Integer.parseInt(factory.nextToken());
			    finaltest[object.length]=Integer.parseInt(factory.nextToken());
			    grade[object.length]=computeNumericGrade(object.length);
			    letter[object.length]=computeLetter(object.length);
			    object.length++;      
			}
			GradingProblemWithArray.sort(grade, id, quiz1, quiz2, quiz3, midterm, finaltest, letter, object.length);
			
			
			
			

			
			for(int i=0;i<object.length;i++){
				 
			outputStream.printf("%-5s%6d%6d%7d%7d%5d%10.1f%12s\r\n",id[i],quiz1[i],quiz2[i],quiz3[i],midterm[i],finaltest[i],grade[i],letter[i]);
			}
			
			 inputStream.close();//����
			 outputStream.close();

	}

	
}
