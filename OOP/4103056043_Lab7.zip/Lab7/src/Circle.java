
public class Circle extends Point {
	private int radius;
	
	public Circle(String name,int x,int y,int radius){//�غc�l
		
		super(name,x,y);
		this.radius=radius;
	}
	public double getArea() {	//overriding
		return Math.rint(radius*radius*Math.PI*10)/10;
		
	}
	public String toString(){//overriding
		return super.toString()+" is the center and the radius is "+radius;
	}

}
