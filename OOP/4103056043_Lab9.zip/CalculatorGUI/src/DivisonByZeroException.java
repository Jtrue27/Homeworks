
public class DivisonByZeroException extends Exception {
	 public DivisonByZeroException(){
	        super("Division by zero exception.");
	    }

}
