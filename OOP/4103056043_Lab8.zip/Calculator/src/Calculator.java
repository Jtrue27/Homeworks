import java.util.Scanner;
public class Calculator {
    public static double  result=0.0;
	public static void main(String[] args) {
		int keepon=1;
		result=0;	
	    System.out.println("Calculator is on.");//��ܭp����Ұ�
	    System.out.println("result = "+result+"(��J�r���n�[�Ů� e.g.+ 5)");//��ܤ@�}�l����
	    while(keepon==1){//�@�����ư��p��
	    Scanner keyword=new Scanner(System.in);//Ū�J
        char c=keyword.next().charAt(0);//���X�Ĥ@�Ӧr��
        double num=0;
        if(c=='r'||c=='R')//�Y��J�h��̲ܳ׵��G�A�èM�w���}or�~��
            forEnd();
        else 
        	 num =keyword.nextDouble();//�Y���OR�A�hŪ�Ʀr���p��
	    try
	    {   
	        if(c=='+') result+=num;
	        else if(c=='-') result-=num;
	        else if(c=='*') result*=num;
	        else if(c=='/'){//�����k
	        	if(num==0) throw new DivisionByZeroException();//�Y�Ʀr=0�Athrow ����0�ҥ~
	        	else result/=num;	//�Ϥ��A �����k
	        }
	        else throw new UnknownOperatorException(String.valueOf(c));//�D�W�z�r���Athrow �����r���ҥ~
	        //�p��
            System.out.println("result" +" "+c+" "+num+" = "+result);
            System.out.println("new result = "+result);
            /*end choice*/
	    }
	    catch(DivisionByZeroException e)
	    {
	        System.out.println(e.getMessage());
	        System.out.println("reenter your last line:");
	        moreChance();
	    }
	    catch(UnknownOperatorException e)
	    {
	        System.out.println(e.getMessage());
	        System.out.println("reenter your last line:");
	        moreChance();
	    }
	    }//End while
		
	}

 
	public  static void forEnd(){//�p�G��Jr�A�������}�{��
		    
        	System.out.println("Final Result = "+result);
        	System.out.println("Again? (y/n)");
        	Scanner keyboard=new Scanner(System.in);
        	char cchar=keyboard.next().charAt(0);
        	if(cchar=='y'||cchar=='Y')  {//���j�I�smain
        		main(null);
        	}
        	else if(cchar=='n'||cchar=='N') {//���쵲�����}�{��
        		System.out.println("Bye Bye");
        		System.exit(0);
        	}
			
        }

	
    public static void moreChance(){ //ReEnter
    	
	        Scanner keyword=new Scanner(System.in);
            char c=keyword.next().charAt(0);
            double num=0;
            if(c=='r'||c=='R')
            	forEnd();
                else 
                	num =keyword.nextDouble();
            try
    	    { 
   
            	if(c=='+') result+=num;
       	        else if(c=='-') result-=num;
       	        else if(c=='*') result*=num;
       	        else if(c=='/') {
       	        	if(num==0) throw new DivisionByZeroException();
       	        	else result/=num; 
       	        }
       	        else throw new UnknownOperatorException(String.valueOf(c));
                   
                   System.out.println("result" +" "+c+" "+num+" = "+result);
                   System.out.println("new result = "+result);
                   moreChance();
                   /*end choice*/
                   
    	    }
    	    catch(DivisionByZeroException e)
    	    {
    	        System.out.println(e.getMessage());
    	        System.out.println("reenter your last line:");
    	        moreChance();
    	    }
    	    catch(UnknownOperatorException e)
    	    {
    	        System.out.println(e.getMessage());
    	        System.out.println("reenter your last line:");
    	        moreChance();
    	    }


	}




	
	
	
}
