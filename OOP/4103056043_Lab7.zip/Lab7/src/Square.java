
public class Square extends Point {
	private int width;
	public Square(String name,int x,int y,int width){//�غc�l
		super(name,x,y);
		this.width=width;
	}
	public double getArea() {	//overriding
		return width*width;
	}
	public String toString(){   //overriding
		return super.toString()+" is the upper left corner. The width is"+" "+width;
	}
}
