import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
	 public static void main(String[] args) {
	    	GradingProblem obj1=new GradingProblem();
	    	
	    	Scanner inputStream=null;        //Ū�ɮ׳]��null��l��
			PrintWriter outputStream=null;
			try //�}��
		    {
		       inputStream=new Scanner(new FileInputStream("inFile3.txt"));  
		       outputStream=new PrintWriter(new FileOutputStream("outFile3.txt"));	
		    }
		    catch(FileNotFoundException ex)//�Y�}�ɥ���
		    {
		       System.out.println("File can not find or open");
		       System.exit(0); //�������}
		    }  
			outputStream.printf("%-5s%6s%6s%7s%8s%6s%13s%12s\r\n","ID","Quiz1" ,"Quiz2" ,"Quiz3", "Midterm" ,"Final","NumericGrade" ,"LetterGrade");
			while(inputStream.hasNextLine()){    
				String inputline=inputStream.nextLine();
				StringTokenizer factory =new StringTokenizer(inputline,"  ");
				obj1.updateID(factory.nextToken());
				obj1.updateQuiz1(Integer.parseInt(factory.nextToken()));
				obj1.updateQuiz2(Integer.parseInt(factory.nextToken()));
				obj1.updateQuiz3(Integer.parseInt(factory.nextToken()));
				obj1.updateMidterm(Integer.parseInt(factory.nextToken()));
				obj1.updateFinaltest(Integer.parseInt(factory.nextToken()));	
			    obj1.updateNumericGrade((obj1.computeNumericGrade()));
			    obj1.updateLetterGrade(obj1.computeLetterGrade());  
			    
			    String x1=obj1.getID();
			    int  x2=obj1.getQuiz1();
			    int x3=obj1.getQuiz2();
			    int x4=obj1.getQuiz3();
			    int x5=obj1.getMidterm();
			    int x6=obj1.getFinaltest();
			    double x7=obj1.getNumericGrade();
			    String x8=obj1.getLetterGrade();
			    outputStream.printf("%-5s%6d%6d%7d%7d%5d%10.0f%12s\r\n",x1,x2,x3,x4,x5,x6,x7,x8);  
			}
		    inputStream.close();//����
		    outputStream.close();
		    
		}

}
