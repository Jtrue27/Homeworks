
public class File extends Document{
	private String pathname;
	public void setPathname(String input){
		   pathname=input;
	   }
    public String getPathname(){
		   return pathname;
	   }
    public String toString(){
    	return "Pathname:"+pathname+"\r\n"+"Text:"+getText();
    }
	

}
